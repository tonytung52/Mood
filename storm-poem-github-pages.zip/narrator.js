/* One narration queue per presentation run. No re-enqueue on render or resume. */
class PoemNarrator {
  constructor(synth, Utterance, notify=()=>{}) { this.synth=synth;this.Utterance=Utterance;this.notify=notify;this.pages=new Map();this.key=null;this.active=null;this.playing=false;this.enabled=true;this.rate=1;this.unavailable=false; }
  select(key, texts) {
    if(this.key===key)return;
    this.cancel();this.key=key;
    if(!this.pages.has(key))this.pages.set(key,{parts:texts.filter(Boolean),index:0});
    this.unavailable=false;
  }
  cancel(){const old=this.active;this.active=null;if(old){old.onend=null;old.onerror=null;}if(this.synth)this.synth.cancel();}
  reset(){this.cancel();this.pages.clear();this.key=null;}
  setPlaying(on){this.playing=on;if(!this.synth)return;if(!on){if(this.active)this.synth.pause();}else if(this.enabled){if(this.active)this.synth.resume();else this.start();}}
  setEnabled(on){this.enabled=on;if(!this.synth)return;if(!on){if(this.active)this.synth.pause();}else if(this.playing){if(this.active)this.synth.resume();else this.start();}}
  setRate(rate){this.rate=rate;}
  start(){
    if(!this.enabled||!this.playing||this.active||this.key===null)return;
    const state=this.pages.get(this.key);if(!state||state.index>=state.parts.length)return;
    const voices=this.synth?this.synth.getVoices().filter(v=>/^zh|cmn/i.test(v.lang)):[];
    if(!voices.length){this.unavailable=true;this.notify('此裝置尚未提供中文語音，仍可閱讀完整賞析。');return;}
    this.unavailable=false;
    const voice=voices.find(v=>/ting[ -]?ting|婷婷/i.test(v.name)&&/premium|enhanced/i.test(v.name))||voices.find(v=>/ting[ -]?ting|婷婷/i.test(v.name))||voices.find(v=>/zh[-_]TW/i.test(v.lang))||voices.find(v=>/zh[-_]CN/i.test(v.lang))||voices[0];
    const u=new this.Utterance(state.parts[state.index]);u.voice=voice;u.lang=voice.lang;u.rate=this.rate*.9;
    this.active=u;
    u.onend=()=>{if(this.active!==u)return;this.active=null;state.index++;this.notify('');this.start();};
    u.onerror=e=>{if(this.active!==u)return;this.active=null;this.unavailable=true;this.notify('朗讀暫時無法繼續，請閱讀「賞析」中的完整說明。');};
    this.notify('');this.synth.resume();this.synth.speak(u);
  }
  waiting(){const p=this.pages.get(this.key);return this.enabled&&!this.unavailable&&!!p&&(!!this.active||p.index<p.parts.length);}
}
if(typeof module!=='undefined')module.exports=PoemNarrator;
