const $=id=>document.getElementById(id);
const poems=['風雨之悶閉門索居，','波瀾不驚閒臥呻吟；','風翻十仞烏光映天，','長煙圍繞霧霾萬頃；','整裝出閘蓄勢待發，','炎氛滌盡清新再起！'];
const titles=['首頁','第一句','第二句','第三句','第四句','第五句','第六句','全詩'];
const meanings=['風雨使人心生鬱悶，於是關起門來，獨自留在屋內。','外在水面平靜，自己閒臥低吟；安靜的景象，也可能藏著內心的不舒暢。','大風翻湧，彷彿直上高空；烏暗的天光映照天幕，氣勢陡然轉強。','綿長的煙雲環繞群山，霧氣鋪滿廣闊天地，視野一時難以看清。','整理衣裝、推門而出，積蓄已久的力量，正準備化為行動。','暑熱與鬱悶彷彿被洗去，天地重新清爽，人也振作，再次出發。'];
const analyses=['「悶」是情緒起點，「閉門索居」把目光收回室內。朗讀放慢，在「悶」之後略作停頓。','「波瀾不驚」與「呻吟」形成外靜內動的張力。此處「呻吟」可理解為低聲吟嘆，並非一定指病痛。','「十仞」在此強化高聳之感，不必換算為精確高度。「烏光」保留原詩用字，解讀為昏暗天光。重讀「風翻」。','「長煙」可視為連綿煙雲，「萬頃」寫出廣闊。拉長「圍繞」的語氣，讓視線隨山霧展開。','全詩在此由靜轉動。「出閘」帶出突破與行動感；「蓄勢待發」逐步加重，讀出準備就緒的力量。','「滌盡」有洗去、清除之意。由天氣轉晴延伸到心境更新；在「清新」稍提亮聲音，「再起」有力收束。'];
const intros=['一卷山水，六句心境。由風雨閉居，走向雨後新生。','窗外風雨，窗內一盞暖光。','水面無波，心事仍在低迴。','風翻高處，暗雲鋪向天際。','煙雲漫山，萬頃天地未明。','推開門扉，讓腳步回應內心。','雨洗群峰，晨光再次抵達。','風雨終有歇，心境可再起。'];
const pageAssets=['portrait.jpg','verse-1-v3.webp','verse-2-v3.webp','verse-3-v3.webp','verse-4-v3.webp','verse-5-v3.webp','verse-6-v3.webp','finale-sage-v3.webp'];
let imageReady=false,imageVersion=0;
let scene=-1,t=0,playing=false,rate=1,narration=true,music=true,last=performance.now(),utterance=null,spokenToken=0;
const synth=window.speechSynthesis;
const bg=$('bgm');bg.volume=.25;function status(s){$('status').textContent=s;}
const narrator=new PoemNarrator(synth,window.SpeechSynthesisUtterance,status);
if(synth)synth.onvoiceschanged=()=>{if(imageReady)narrator.start();};
function speak(){if(imageReady)narrator.start();}
function narrationText(){
 // Narrate visible page headings and main text only; the optional analysis is silent.
 // Identical text appearing in both places is spoken only once on this page.
 const seen=new Set();const parts=[];
 for(const el of document.querySelectorAll('#slide [data-narrate]')){
  const copy=el.cloneNode(true);copy.querySelectorAll('br').forEach(br=>br.replaceWith(document.createTextNode('。')));
  const text=copy.textContent.trim();const key=text.replace(/[\s，。；！？、·・]/g,'');
  if(text&&!seen.has(key)){seen.add(key);parts.push(text);}
 }
 $('slide').dataset.narration=JSON.stringify(parts);
 return parts;
}
function render(){const next=Math.min(7,Math.floor(t/30));if(next===scene)return;scene=next;document.body.dataset.scene=scene;const isEnd=scene===7,isIntro=scene===0;const asset=pageAssets[scene];const h=isIntro?'<span>風雨之後</span><span>清新再起</span>':isEnd?'六句・一程山水':poems[scene-1].slice(0,4)+'<span>'+poems[scene-1].slice(4)+'</span>';
$('slide').className=isIntro?'intro':isEnd?'ending':'painting';
$('slide').innerHTML=isIntro?`<figure class="art portrait"><img src="assets/portrait.jpg" alt="古裝人物完整肖像"></figure><div class="copy"><small class="eyebrow" data-narrate>山水詩境 · 六幅畫，一段心路</small><h1 data-narrate>風雨之後<br>清新再起</h1><p data-narrate>從閉門聽雨，到整裝再起。<br>隨六句詩，走入一卷流動山水。</p></div>`:isEnd?`<figure class="art"><img src="assets/finale-sage-v3.webp" alt="陽光普照蒼翠森林，溪流瀑布間的悠閒智者仰望天空"></figure><div class="copy"><small class="eyebrow" data-narrate>風雨之後 · 全詩</small><div class="allpoem">${poems.map(line=>'<p data-narrate>'+line+'</p>').join('')}</div></div>`:`<figure class="art"><img src="assets/${asset}" alt="${poems[scene-1]} ${intros[scene]}"><div class="painting-mist"></div><div class="painting-spark"></div></figure><div class="caption"><span data-narrate>${titles[scene]}</span><h1 data-narrate>${poems[scene-1]}</h1><p class="brief" data-narrate>${meanings[scene-1]}</p></div>`;
$('pageNumber').textContent=(scene+1)+' / 8';
imageReady=false; const version=++imageVersion; const artwork=$('slide').querySelector('img'); artwork.fetchPriority='high';
const ready=()=>{if(version!==imageVersion)return;imageReady=true;status('');speak();};
artwork.onload=ready;artwork.onerror=()=>{if(version===imageVersion){imageReady=false;status('圖片未能載入，請點此重試');$('status').onclick=()=>{status('正在載入畫作…');artwork.src='assets/'+asset+'?retry='+Date.now();};}};
$('status').onclick=null;
if(artwork.complete&&artwork.naturalWidth>0){imageReady=true;}else{status('正在載入畫作…');}
if(scene<7){const preload=new Image();preload.src='assets/'+pageAssets[scene+1];}

$('slide').style.animation='none';void $('slide').offsetWidth;$('slide').style.animation='';[...$('chapters').children].forEach((b,i)=>{b.classList.toggle('active',i===scene);b.setAttribute('aria-current',i===scene?'step':'false');});history.replaceState(null,'','#'+(scene+1));updateLesson();narrator.select(scene,narrationText());speak();}
function updateLesson(){const i=Math.max(0,Math.min(5,scene-1));$('lessonTitle').textContent=scene===0?'由風雨閉居，到清新再起':scene===7?'讀完之後，回望這段心路':poems[i];$('meaning').textContent=scene===0?'六句詩以天氣與山水的變化，串起閉居、靜思、風起、煙霧、出發與更新。':scene===7?'前四句鋪陳風雨與內在情緒，後兩句轉入行動與振作，形成由鬱悶到清新的轉折。':meanings[i];$('analysis').textContent=scene===0?'先看畫面，再讀詩句；每幕可以暫停，打開導讀慢慢品味。畫面中的星光與漁火，是配合您要求加入的視覺意象。':scene===7?'試著比較第一句的「悶」與最後一句的「清新」：相同的人，如何在風雨之後改變觀看世界的方式？':analyses[i];}
function clock(x){return String(Math.floor(x/60)).padStart(2,'0')+':'+String(Math.floor(x%60)).padStart(2,'0');}function progress(){$('progress').value=t;$('clock').textContent=clock(t);}
function syncMusic(){if(music&&playing)bg.play().catch(()=>status('配樂未能啟動，請再點一次「配樂」。'));else bg.pause();}
function play(){if(!playing&&t>=240){narrator.reset();scene=-1;t=0;}playing=!playing;document.body.classList.toggle('paused',!playing);$('play').textContent=playing?'❚❚ 暫停':'▶ 播放';if(playing){render();narrator.playing=true;if(imageReady)narrator.setPlaying(true);}else narrator.setPlaying(false);syncMusic();}
function seek(n){t=Math.max(0,Math.min(239.99,n));render();if(bg.duration)bg.currentTime=t%bg.duration;progress();}
function tick(now){const dt=Math.min(.25,(now-last)/1000);last=now;if(playing&&imageReady){const end=(scene+1)*30;const candidate=t+dt*rate;
 if(candidate>=end&&narrator.waiting()){t=end-.01;}else{t=candidate;if(t>=240){t=240;playing=false;narrator.setPlaying(false);document.body.classList.add('paused');$('play').textContent='▶ 重播';syncMusic();status('播放完畢');}else render();}progress();}draw(now);requestAnimationFrame(tick);}
titles.forEach((title,i)=>{const b=document.createElement('button');b.textContent=String(i+1);b.setAttribute('aria-label','第'+(i+1)+'頁：'+title);b.title=title;b.onclick=()=>{seek(i*30);};$('chapters').append(b);});$('play').onclick=play;$('prev').onclick=()=>seek((scene-1)*30);$('next').onclick=()=>seek((scene+1)*30);$('back').onclick=()=>seek(t-10);$('forward').onclick=()=>seek(t+10);$('progress').oninput=e=>seek(+e.target.value);$('rate').onchange=e=>{rate=+e.target.value;narrator.setRate(rate);};$('read').onclick=()=>{narration=!narration;$('read').textContent='朗讀：'+(narration?'開':'關');narrator.setEnabled(narration);};$('music').onclick=()=>{music=!music;$('music').textContent='配樂：'+(music?'開':'關');syncMusic();};$('volume').oninput=e=>bg.volume=+e.target.value;$('learn').onclick=()=>$('lesson').hidden=!$('lesson').hidden;$('closeLesson').onclick=()=>$('lesson').hidden=true;$('help').onclick=()=>$('guide').showModal();$('closeGuide').onclick=()=>$('guide').close();$('options').onclick=()=>$('optionsPanel').showModal();$('closeOptions').onclick=()=>$('optionsPanel').close();$('full').onclick=()=>{if(document.fullscreenElement)document.exitFullscreen();else if(document.documentElement.requestFullscreen)document.documentElement.requestFullscreen().catch(()=>status('此裝置不支援全螢幕，請橫向觀看。'));else status('此裝置不支援網頁全螢幕，請橫向觀看。');};document.addEventListener('keydown',e=>{if(/INPUT|SELECT|BUTTON/.test(e.target.tagName)||$('guide').open||$('optionsPanel').open)return;if(e.code==='Space'){e.preventDefault();play();}if(e.code==='ArrowRight')seek((scene+1)*30);if(e.code==='ArrowLeft')seek((scene-1)*30);});document.addEventListener('pointermove',e=>{document.documentElement.style.setProperty('--x',(e.clientX/innerWidth-.5)*10+'px');document.documentElement.style.setProperty('--y',(e.clientY/innerHeight-.5)*7+'px');});window.addEventListener('hashchange',()=>{const n=+location.hash.slice(1);if(n>=1&&n<=8)seek((n-1)*30);});
// Layered ink silhouettes: foreground planes move farther than distant peaks.
for(let layer=0;layer<4;layer++){const el=document.createElement('div');el.className='mountain';el.style.setProperty('--d',(layer+1)*.6);let points='0,800 0,'+(420+layer*50);for(let x=0;x<=1600;x+=25){const y=360+layer*80-Math.abs(Math.sin(x*.0038+layer*2)*Math.cos(x*.0019+layer))*330-Math.sin(x*.029+layer)*22;points+=` ${x},${y}`;}points+=' 1600,800';el.innerHTML=`<svg viewBox="0 0 1600 800" preserveAspectRatio="none"><defs><filter id="rough${layer}"><feTurbulence baseFrequency=".017" numOctaves="3" seed="${layer}"/><feDisplacementMap in="SourceGraphic" scale="14"/></filter></defs><polygon points="${points}" fill="${['#496063','#30494d','#18353b','#09252e'][layer]}" opacity=".8" filter="url(#rough${layer})"/></svg>`;$('mountains').append(el);}
const canvas=$('particles'),ctx=canvas.getContext('2d');let w=0,h=0;function resize(){w=innerWidth;h=innerHeight;canvas.width=w;canvas.height=h;}resize();addEventListener('resize',resize);const dots=Array.from({length:100},()=>({x:Math.random(),y:Math.random(),p:Math.random()*6,r:Math.random()*1.4+.4}));let visual=0;const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;function draw(now){if(playing&&!reduced)visual+=.016;ctx.clearRect(0,0,w,h);for(const d of dots){if(scene===1||scene===3){ctx.strokeStyle='#bbd9e333';ctx.beginPath();const x=(d.x*w+visual*90)%w,y=(d.y*h+visual*280)%h;ctx.moveTo(x,y);ctx.lineTo(x-7,y+23);ctx.stroke();}else{ctx.fillStyle=`rgba(242,225,181,${(.35+Math.sin(visual+d.p)*.25)*(d.y<.5?1:.25)})`;ctx.beginPath();ctx.arc(d.x*w,d.y*h*.8,d.r,0,7);ctx.fill();}}if(scene===3&&!reduced){const flash=Math.pow(Math.max(0,Math.sin(visual*.7)),45)*.12;ctx.fillStyle=`rgba(210,220,240,${flash})`;ctx.fillRect(0,0,w,h);}}
document.body.classList.add('paused');t=Math.max(0,Math.min(7,(+location.hash.slice(1)||1)-1))*30;render();progress();requestAnimationFrame(tick);
